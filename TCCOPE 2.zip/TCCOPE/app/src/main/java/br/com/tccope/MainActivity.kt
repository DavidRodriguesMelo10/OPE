package br.com.tccope

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val txtEmail = findViewById<TextView>(R.id.textInputEmail)
        txtEmail.text = getString(R.string.Email)

        val txtSenha = findViewById<TextView>(R.id.textInputSenha)
        txtSenha.text = getString(R.string.Senha)

        textInputEmail.setOnClickListener {
            Toast.makeText(baseContext, "Digite seu Email" , Toast.LENGTH_LONG).show()
            if (validInputs () ) {
                txtEmail.text.toString().trim()

            }
        }


        textInputSenha.setOnClickListener {
            Toast.makeText(baseContext, "Digite sua Senha" , Toast.LENGTH_LONG).show()
            if (validInputs () ) {
                txtSenha.text.toString().trim()

            }

        }

        buttonLogin.setOnClickListener {

            goToHome()
        }

    }


    override fun onResume() {
        super.onResume()


    }

    private fun validInputs(): Boolean {

        if (textInputEmail.text!!.length < 3) {
            Toast.makeText(baseContext, "Email invalido " , Toast.LENGTH_LONG).show()
            return false
        }

        if (textInputSenha.text!!.length < 3) {
            Toast.makeText(baseContext, "Senha invalida " , Toast.LENGTH_LONG).show()
            return false
        }


        return true

    }


    fun goToHome(){

        val intent = Intent(this,HomeActivity::class.java)
        startActivity(intent)
    }


}